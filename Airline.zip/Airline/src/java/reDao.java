/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rakshana S
 */
    import java.sql.*; 
public class reDao {
     public String authenticateUser(String user,String email, String pass, String phone) throws ClassNotFoundException
     {
    	 String userName = user;
         String mail=email;
         String password = pass;   
         String phoneno=phone;
         try
         {
        	 Class.forName("com.mysql.jdbc.Driver");
     		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","");
             PreparedStatement stmt = con.prepareStatement("insert into login values(?,?,?)");
             stmt.setString(1, userName);
             stmt.setString(2, email);
             stmt.setString(3, password); 
             int i= stmt.executeUpdate();
             if (i!=0)  //Just to ensure data has been inserted into the database
                 return "SUCCESS"; 
         }
             catch(SQLException e)
             {
                e.printStackTrace();
             }
         return "Oops.. Something went wrong there..!";
     }
}
    
